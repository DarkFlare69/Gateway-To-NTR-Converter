#ifndef VALUES_H
#define VALUES_H

#define CustomValuesDefinedHere 5000

#endif