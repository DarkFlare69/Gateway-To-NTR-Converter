#ifndef CHEATS_H
#define CHEATS_H

#include "plugin.h"

void	code_OneTwoThreeFour(void);

#endif
