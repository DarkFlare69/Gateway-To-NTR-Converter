#include "cheats.h"
#include <stdbool.h>
#include "hid.h"
#include "values.h"
#include <string.h>

u32 offset = 0;
u32 data = 0;
u32 patch_address = 0;

void	code_OneTwoThreeFour(void)
{
	offset = 0;
	WRITEU8(offset + 0x1234, 0xFF);
	offset = 0;
	data = 0;
}

