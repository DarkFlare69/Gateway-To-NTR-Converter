#ifndef CHEATS_H
#define CHEATS_H

#include "plugin.h"

void	MaxInf_AP_vOne_Five(void);

#endif
