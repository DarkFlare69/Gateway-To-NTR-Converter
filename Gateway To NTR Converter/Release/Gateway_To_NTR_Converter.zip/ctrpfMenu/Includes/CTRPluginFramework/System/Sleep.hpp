#ifndef CTRPLUGINFRAMEWORK_SLEEP_HPP
#define CTRPLUGINFRAMEWORK_SLEEP_HPP


namespace CTRPluginFramework
{
    class Time;
    
    void    Sleep(Time sleepTime);
}

#endif
