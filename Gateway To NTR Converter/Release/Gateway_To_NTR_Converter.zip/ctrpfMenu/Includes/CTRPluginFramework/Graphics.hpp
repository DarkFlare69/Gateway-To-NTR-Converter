#ifndef CTRPLUGINFRAMEWORK_GRAPHICS_HPP
#define CTRPLUGINFRAMEWORK_GRAPHICS_HPP

#include "CTRPluginFramework/Graphics/Color.hpp"
#include "CTRPluginFramework/Graphics/OSD.hpp"

#endif